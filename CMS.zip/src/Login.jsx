import Navbar from "./Components/Navbar"
import LoginForm from "./Components/Login/loginForm"



function Login(){

    return (
        <>
            <Navbar />
            <LoginForm />
        </>
    );
}

export default Login;